We have used the following versions of sieve:
1. Base Algorithm (sieve_base_serial.c)
2. Applying the optimization-1 on-base algorithm (sieve_base_optimization1.c)
3. Applying the optimization-2 on-base algorithm (sieve_base_optimization2.c)
4. Serial version of block-wise strategy. (sieve_block_wise_serial.c)
5. Parallelized version of blockwise code. (sieve_block_wise_parallel.c)
6. The further optimized version of above code. (sieve_block_wise_parallel_optimization.c)

All of these codes are in source_code folder.

Inputs:
We have used file-based input and output.

All the input files and output files we have used can be found in their respective folder.
input 00.txt  -  Execution Time vs. number of Processors
	     N = 1000000000
	     B = 31622
             P = 1 to 16
input 01.txt  -  Execution Time vs. N
	     N = {2^15,2^16,2^17,...,2^29}
             B = sqrt(N)
             P = 1
input 02.txt  -  Execution Time vs. N
             N = {2^15,2^16,2^17,...,2^29}
             B = sqrt(N)
             p = {1,4,7,10,13,16} 

Note: To run the code, input files and the source code should be in the same folder. 
And to run the 6th version of the code, the input should be given (Test cases, N, B, p) in this order in terminal.

All the results(graphs) are in the result folder.

We have also added the python script used to generate these graphs.
 
