#include<stdio.h>
#include<math.h>
#include<omp.h>
#include<time.h>
#include<string.h>
#include<stdlib.h>
#include<stdbool.h>
#define min(x, y) (((x) < (y)) ? (x) : (y))
#define CLK CLOCK_MONOTONIC

struct timespec diff(struct timespec start, struct timespec end);

struct timespec diff(struct timespec start, struct timespec end){
        struct timespec temp;
        if((end.tv_nsec-start.tv_nsec)<0){
                temp.tv_sec = end.tv_sec-start.tv_sec-1;
                temp.tv_nsec = 1000000000+end.tv_nsec-start.tv_nsec;
        }
        else{
                temp.tv_sec = end.tv_sec-start.tv_sec;
                temp.tv_nsec = end.tv_nsec-start.tv_nsec;
        }
        return temp;
}
int max_discoverd_prime=0;
int main(int argc, char* argv[])
{
    FILE *fp,*fp2;
    fp=freopen("input12.txt","r+",stdin);
    fp2=freopen("output13.txt","w+",stdout);
    struct timespec start_e2e, end_e2e, start_alg, end_alg, e2e, alg;

    int i1;
    int x;
    scanf("%d",&x);
    
    for( i1=0;i1<x;i1++)
    {
	clock_gettime(CLK, &start_e2e);

        int n,p,blocksize;
        scanf("%d%d%d",&n,&blocksize,&p);

        int i,j;
        //Initialize
        char *prime=malloc(sizeof(char)*(n+1));
        for(i=0;i<=n;i++)
        {
            prime[i]=0;
        }
        clock_gettime(CLK, &start_alg);
        int sqrtn=sqrt(n);
        //find all odd non-primes
        for(i=3;i<=sqrtn;i+=2)
        {
            if(prime[i]==0)
            {
                //mark all non primes
                for(j=i*i;j<=n;j+=2*i)
                {
                    prime[j]=1;
                }
            }
        }
        clock_gettime(CLK, &end_alg);
        //algorithm is complete count primes and also find maximum prime in the range
        int num_of_primes=1;
        for(i=3;i<=n;i+=2)
        {
            if(prime[i]==0)
            {
                num_of_primes++;
                if(max_discoverd_prime<i)
                {
                    max_discoverd_prime=i;
                }
            }
        }
        clock_gettime(CLK, &end_e2e);

        e2e = diff(start_e2e, end_e2e);
        alg = diff(start_alg, end_alg);
        printf("%d %d %d %d %d %d\n",num_of_primes,max_discoverd_prime, e2e.tv_sec, e2e.tv_nsec, alg.tv_sec, alg.tv_nsec);
    }
    return 0;
}
