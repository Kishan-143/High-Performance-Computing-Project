#include<stdio.h>
#include<math.h>
#include<omp.h>
#include<time.h>
#include<string.h>
#include<stdlib.h>
#include<stdbool.h>
#define min(x, y) (((x) < (y)) ? (x) : (y))
#define CLK CLOCK_MONOTONIC

struct timespec diff(struct timespec start, struct timespec end);

struct timespec diff(struct timespec start, struct timespec end){
        struct timespec temp;
        if((end.tv_nsec-start.tv_nsec)<0){
                temp.tv_sec = end.tv_sec-start.tv_sec-1;
                temp.tv_nsec = 1000000000+end.tv_nsec-start.tv_nsec;
        }
        else{
                temp.tv_sec = end.tv_sec-start.tv_sec;
                temp.tv_nsec = end.tv_nsec-start.tv_nsec;
        }
        return temp;
}

// Core Algorithm :-------------------------------
long long int max_discoverd_prime=0;
long long int eratosthenesOddSingleBlock(long long int first,long long int last)
{
    long long int i,j;
    const int memorySize = (last - first + 1) / 2;
    char* isPrime = malloc(sizeof(char)*(memorySize));
    for (i = 0; i < memorySize; i++)
    {
        isPrime[i] = '1';
    }
    for(i=3;i*i<=last;i+=2)
    {
        //skip multiples of 3,5,7,11
        if((i>=3*3 && (i%3)==0) || (i>=5*5 && (i%5)==0) || (i>=7*7 && (i%7)==0) || (i>=11*11 && (i%11)==0))
        {
            continue;
        }

        long long int min_ele = ((first+i-1)/i)*i;

        if(min_ele < i*i)
        {
            min_ele=i*i;
        }

        if ( (min_ele%2)==0)
        {
            min_ele+=i;
        }

        for(j = min_ele; j <= last; j += 2*i)
        {
            int idx = j - first;
            isPrime[idx/2] = '0';
        }
    }
    //count primes and also find max prime in given range
    long long int found = 0;
    for (i = 0; i < memorySize; i++)
    {
        found += isPrime[i]-'0';
        if(isPrime[i]=='1')
        {
            long long int num = (first+2*i);
	    if(num>0) num++;
            if(num > max_discoverd_prime)
            {
                max_discoverd_prime=num;
            }
        }
    }

    if (first <= 2)
    {
        found++;
    }
    free(isPrime);
    return found;
}
long long int eratosthenesBlockwise(long long int n, long long int blocksize)
{
    long long int i;
    long long int num_of_primes2 = 0;
    //parallelized the loop
    #pragma omp parallel for reduction(+:num_of_primes2)
    for (i = 2; i <= n; i+=blocksize)
    {
        long long int last = i + blocksize;
        if (last > n)
        {
            last=n;
        }
        num_of_primes2 += eratosthenesOddSingleBlock(i,last);
    }
    return num_of_primes2;
}
int main(int argc, char* argv[])
{    
    struct timespec start_e2e, end_e2e, start_alg, end_alg, e2e, alg;

    // x is number of input from terminals
    int i,x;
    scanf("%d",&x);
    for( i=0;i<x;i++)
    {
	clock_gettime(CLK, &start_e2e);

        long long int n,p,blocksize;
        scanf("%ld%ld%ld",&n,&blocksize,&p);

        clock_gettime(CLK, &start_alg);
        omp_set_num_threads(p);

        long long int num_of_primes=eratosthenesBlockwise(n,blocksize);

        clock_gettime(CLK, &end_alg);
        clock_gettime(CLK, &end_e2e);

        alg = diff(start_alg, end_alg);
        e2e = diff(start_e2e, end_e2e);

	printf(" %ld %ld %ld %ld %ld %ld\n",num_of_primes,max_discoverd_prime, e2e.tv_sec, e2e.tv_nsec, alg.tv_sec, alg.tv_nsec);
    }
    return 0;
}
